/* eslint-disable */
// @ts-nocheck

"use strict";
export const validate = validate14;
export default validate14;
const schema16 = {"$id":"https://github.com/data-fair/catalog-mock/catalog-config","x-exports":["types","validate","schema"],"title":"MockConfig","type":"object","additionalProperties":false,"required":["url","delay"],"properties":{"url":{"type":"string","title":"URL","description":"The url of the catalog","x-i18n-description":{"fr":"L'URL de l'API du catalogue"},"pattern":"^https?://.*[^/]$","errorMessage":"The URL must start with http:// or https:// and must not end with `/`.","x-i18n-errorMessage":{"fr":"L'URL doit commencer par http:// ou https:// et ne pas se terminer par `/`."},"examples":["https://example.com"]},"secretField":{"type":"string","title":"Secret Field","x-i18n-title":{"fr":"Champ chiffré"},"description":"A secret field that is ciphered but for testing purposes, shown in the description of imported datasets.","x-i18n-description":{"fr":"Un champ secret qui est chiffré mais qui, à des fins de test, est affiché dans la description des jeux de données importés."},"layout":{"props":{"type":"password","autocomplete":"new-password"}}},"thumbnailUrl":{"type":"string","title":"Thumbnail URL","x-i18n-title":{"fr":"URL de la vignette"},"description":"The URL of the thumbnail image for the catalog. If not provided, no thumbnail will be displayed.","x-i18n-description":{"fr":"L'URL de l'image miniature du catalogue. Si non fourni, aucune vignette ne sera affichée."},"pattern":"^https?://.*[^/]$","errorMessage":"The Thumbnail URL must start with http:// or https:// and must not end with `/`.","x-i18n-errorMessage":{"fr":"L'URL de la vignette doit commencer par http:// ou https:// et ne pas se terminer par `/`."},"examples":["https://cdn.jsdelivr.net/gh/data-fair/data-fair@master/ui/public/assets/logo.svg"],"layout":{"props":{"clearable":true}}},"delay":{"type":"number","title":"Response Delay","x-i18n-title":{"fr":"Délai de réponse"},"description":"Adds a response delay (in ms) to requests to simulate server response time. Set to 0 to disable.","x-i18n-description":{"fr":"Ajoute un temps de réponse (en ms) aux requêtes pour simuler un délai de réponse du serveur. La valeur 0 désactive le délai."},"default":500,"minimum":0,"maximum":60000,"layout":{"cols":4,"props":{"step":100}}},"searchCapability":{"type":"boolean","title":"Search Capability","x-i18n-title":{"fr":"Capacité de recherche"},"description":"Indicates whether the catalog dynamically supports the search feature.","x-i18n-description":{"fr":"Indique si le catalogue prend en charge dynamiquement la fonctionnalité de recherche."},"default":true,"layout":{"comp":"switch","cols":4}},"paginationCapability":{"type":"boolean","title":"Pagination Capability","x-i18n-title":{"fr":"Capacité de pagination"},"description":"Indicates whether the catalog dynamically supports pagination.","x-i18n-description":{"fr":"Indique si le catalogue prend en charge dynamiquement la pagination."},"default":true,"layout":{"comp":"switch","cols":4}},"publicationMode":{"type":"string","title":"Publication Mode","x-i18n-title":{"fr":"Mode de publication"},"description":"Select the publication mode to test different scenarios: 'none' for no publication capabilities, 'simple' for basic publication (one capability), 'full' for all publication capabilities, or 'withSite' for all capabilities including requiresPublicationSite.","x-i18n-description":{"fr":"Sélectionnez le mode de publication pour tester différents scénarios : 'none' pour aucune capacité de publication, 'simple' pour une publication basique (une seule capacité), 'full' pour toutes les capacités de publication, ou 'withSite' pour toutes les capacités y compris requiresPublicationSite."},"default":"full","layout":{"cols":6},"oneOf":[{"const":"none","title":"No publication","x-i18n-title":{"fr":"Aucune publication"}},{"const":"simple","title":"Simple (createFolderInRoot only)","x-i18n-title":{"fr":"Simple (createFolderInRoot uniquement)"}},{"const":"full","title":"Full (all publication capabilities)","x-i18n-title":{"fr":"Complet (toutes les capacités de publication)"}},{"const":"withSite","title":"With publication site (requiresPublicationSite)","x-i18n-title":{"fr":"Avec site de publication (requiresPublicationSite)"}}]}}};
const pattern0 = new RegExp("^https?://.*[^/]$", "u");

function validate14(data, {instancePath="", parentData, parentDataProperty, rootData=data}={}){
/*# sourceURL="https://github.com/data-fair/catalog-mock/catalog-config" */;
let vErrors = null;
let errors = 0;
if(data && typeof data == "object" && !Array.isArray(data)){
if(data.url === undefined){
const err0 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "url"},message:"must have required property '"+"url"+"'"};
if(vErrors === null){
vErrors = [err0];
}
else {
vErrors.push(err0);
}
errors++;
}
if(data.delay === undefined){
const err1 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "delay"},message:"must have required property '"+"delay"+"'"};
if(vErrors === null){
vErrors = [err1];
}
else {
vErrors.push(err1);
}
errors++;
}
for(const key0 in data){
if(!(((((((key0 === "url") || (key0 === "secretField")) || (key0 === "thumbnailUrl")) || (key0 === "delay")) || (key0 === "searchCapability")) || (key0 === "paginationCapability")) || (key0 === "publicationMode"))){
const err2 = {instancePath,schemaPath:"#/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key0},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err2];
}
else {
vErrors.push(err2);
}
errors++;
}
}
if(data.url !== undefined){
let data0 = data.url;
if(typeof data0 === "string"){
if(!pattern0.test(data0)){
const err3 = {instancePath:instancePath+"/url",schemaPath:"#/properties/url/pattern",keyword:"pattern",params:{pattern: "^https?://.*[^/]$"},message:"must match pattern \""+"^https?://.*[^/]$"+"\""};
if(vErrors === null){
vErrors = [err3];
}
else {
vErrors.push(err3);
}
errors++;
}
}
else {
const err4 = {instancePath:instancePath+"/url",schemaPath:"#/properties/url/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err4];
}
else {
vErrors.push(err4);
}
errors++;
}
if(errors > 0){
const emErrs0 = [];
for(const err5 of vErrors){
if(((((err5.keyword !== "errorMessage") && (!err5.emUsed)) && ((err5.instancePath === instancePath+"/url") || ((err5.instancePath.indexOf(instancePath+"/url") === 0) && (err5.instancePath[instancePath+"/url".length] === "/")))) && (err5.schemaPath.indexOf("#/properties/url") === 0)) && (err5.schemaPath["#/properties/url".length] === "/")){
emErrs0.push(err5);
err5.emUsed = true;
}
}
if(emErrs0.length){
const err6 = {instancePath:instancePath+"/url",schemaPath:"#/properties/url/errorMessage",keyword:"errorMessage",params:{errors: emErrs0},message:"The URL must start with http:// or https:// and must not end with `/`."};
if(vErrors === null){
vErrors = [err6];
}
else {
vErrors.push(err6);
}
errors++;
}
const emErrs1 = [];
for(const err7 of vErrors){
if(!err7.emUsed){
emErrs1.push(err7);
}
}
vErrors = emErrs1;
errors = emErrs1.length;
}
}
if(data.secretField !== undefined){
if(typeof data.secretField !== "string"){
const err8 = {instancePath:instancePath+"/secretField",schemaPath:"#/properties/secretField/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err8];
}
else {
vErrors.push(err8);
}
errors++;
}
}
if(data.thumbnailUrl !== undefined){
let data2 = data.thumbnailUrl;
if(typeof data2 === "string"){
if(!pattern0.test(data2)){
const err9 = {instancePath:instancePath+"/thumbnailUrl",schemaPath:"#/properties/thumbnailUrl/pattern",keyword:"pattern",params:{pattern: "^https?://.*[^/]$"},message:"must match pattern \""+"^https?://.*[^/]$"+"\""};
if(vErrors === null){
vErrors = [err9];
}
else {
vErrors.push(err9);
}
errors++;
}
}
else {
const err10 = {instancePath:instancePath+"/thumbnailUrl",schemaPath:"#/properties/thumbnailUrl/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err10];
}
else {
vErrors.push(err10);
}
errors++;
}
if(errors > 0){
const emErrs2 = [];
for(const err11 of vErrors){
if(((((err11.keyword !== "errorMessage") && (!err11.emUsed)) && ((err11.instancePath === instancePath+"/thumbnailUrl") || ((err11.instancePath.indexOf(instancePath+"/thumbnailUrl") === 0) && (err11.instancePath[instancePath+"/thumbnailUrl".length] === "/")))) && (err11.schemaPath.indexOf("#/properties/thumbnailUrl") === 0)) && (err11.schemaPath["#/properties/thumbnailUrl".length] === "/")){
emErrs2.push(err11);
err11.emUsed = true;
}
}
if(emErrs2.length){
const err12 = {instancePath:instancePath+"/thumbnailUrl",schemaPath:"#/properties/thumbnailUrl/errorMessage",keyword:"errorMessage",params:{errors: emErrs2},message:"The Thumbnail URL must start with http:// or https:// and must not end with `/`."};
if(vErrors === null){
vErrors = [err12];
}
else {
vErrors.push(err12);
}
errors++;
}
const emErrs3 = [];
for(const err13 of vErrors){
if(!err13.emUsed){
emErrs3.push(err13);
}
}
vErrors = emErrs3;
errors = emErrs3.length;
}
}
if(data.delay !== undefined){
let data3 = data.delay;
if(typeof data3 == "number"){
if(data3 > 60000 || isNaN(data3)){
const err14 = {instancePath:instancePath+"/delay",schemaPath:"#/properties/delay/maximum",keyword:"maximum",params:{comparison: "<=", limit: 60000},message:"must be <= 60000"};
if(vErrors === null){
vErrors = [err14];
}
else {
vErrors.push(err14);
}
errors++;
}
if(data3 < 0 || isNaN(data3)){
const err15 = {instancePath:instancePath+"/delay",schemaPath:"#/properties/delay/minimum",keyword:"minimum",params:{comparison: ">=", limit: 0},message:"must be >= 0"};
if(vErrors === null){
vErrors = [err15];
}
else {
vErrors.push(err15);
}
errors++;
}
}
else {
const err16 = {instancePath:instancePath+"/delay",schemaPath:"#/properties/delay/type",keyword:"type",params:{type: "number"},message:"must be number"};
if(vErrors === null){
vErrors = [err16];
}
else {
vErrors.push(err16);
}
errors++;
}
}
if(data.searchCapability !== undefined){
if(typeof data.searchCapability !== "boolean"){
const err17 = {instancePath:instancePath+"/searchCapability",schemaPath:"#/properties/searchCapability/type",keyword:"type",params:{type: "boolean"},message:"must be boolean"};
if(vErrors === null){
vErrors = [err17];
}
else {
vErrors.push(err17);
}
errors++;
}
}
if(data.paginationCapability !== undefined){
if(typeof data.paginationCapability !== "boolean"){
const err18 = {instancePath:instancePath+"/paginationCapability",schemaPath:"#/properties/paginationCapability/type",keyword:"type",params:{type: "boolean"},message:"must be boolean"};
if(vErrors === null){
vErrors = [err18];
}
else {
vErrors.push(err18);
}
errors++;
}
}
if(data.publicationMode !== undefined){
let data6 = data.publicationMode;
if(typeof data6 !== "string"){
const err19 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err19];
}
else {
vErrors.push(err19);
}
errors++;
}
const _errs16 = errors;
let valid1 = false;
let passing0 = null;
const _errs17 = errors;
if("none" !== data6){
const err20 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/oneOf/0/const",keyword:"const",params:{allowedValue: "none"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err20];
}
else {
vErrors.push(err20);
}
errors++;
}
var _valid0 = _errs17 === errors;
if(_valid0){
valid1 = true;
passing0 = 0;
}
const _errs18 = errors;
if("simple" !== data6){
const err21 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/oneOf/1/const",keyword:"const",params:{allowedValue: "simple"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err21];
}
else {
vErrors.push(err21);
}
errors++;
}
var _valid0 = _errs18 === errors;
if(_valid0 && valid1){
valid1 = false;
passing0 = [passing0, 1];
}
else {
if(_valid0){
valid1 = true;
passing0 = 1;
}
const _errs19 = errors;
if("full" !== data6){
const err22 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/oneOf/2/const",keyword:"const",params:{allowedValue: "full"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err22];
}
else {
vErrors.push(err22);
}
errors++;
}
var _valid0 = _errs19 === errors;
if(_valid0 && valid1){
valid1 = false;
passing0 = [passing0, 2];
}
else {
if(_valid0){
valid1 = true;
passing0 = 2;
}
const _errs20 = errors;
if("withSite" !== data6){
const err23 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/oneOf/3/const",keyword:"const",params:{allowedValue: "withSite"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err23];
}
else {
vErrors.push(err23);
}
errors++;
}
var _valid0 = _errs20 === errors;
if(_valid0 && valid1){
valid1 = false;
passing0 = [passing0, 3];
}
else {
if(_valid0){
valid1 = true;
passing0 = 3;
}
}
}
}
if(!valid1){
const err24 = {instancePath:instancePath+"/publicationMode",schemaPath:"#/properties/publicationMode/oneOf",keyword:"oneOf",params:{passingSchemas: passing0},message:"must match exactly one schema in oneOf"};
if(vErrors === null){
vErrors = [err24];
}
else {
vErrors.push(err24);
}
errors++;
}
else {
errors = _errs16;
if(vErrors !== null){
if(_errs16){
vErrors.length = _errs16;
}
else {
vErrors = null;
}
}
}
}
}
else {
const err25 = {instancePath,schemaPath:"#/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err25];
}
else {
vErrors.push(err25);
}
errors++;
}
validate14.errors = vErrors;
return errors === 0;
}
