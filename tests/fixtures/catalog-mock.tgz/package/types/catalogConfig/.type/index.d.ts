
export const schemaExports: string[]

// see https://github.com/bcherny/json-schema-to-typescript/issues/439 if some types are not exported
/**
 * The url of the catalog
 */
export type URL = string;
/**
 * A secret field that is ciphered but for testing purposes, shown in the description of imported datasets.
 */
export type SecretField = string;
/**
 * The URL of the thumbnail image for the catalog. If not provided, no thumbnail will be displayed.
 */
export type ThumbnailURL = string;
/**
 * Adds a response delay (in ms) to requests to simulate server response time. Set to 0 to disable.
 */
export type ResponseDelay = number;
/**
 * Indicates whether the catalog dynamically supports the search feature.
 */
export type SearchCapability = boolean;
/**
 * Indicates whether the catalog dynamically supports pagination.
 */
export type PaginationCapability = boolean;
/**
 * Select the publication mode to test different scenarios: 'none' for no publication capabilities, 'simple' for basic publication (one capability), 'full' for all publication capabilities, or 'withSite' for all capabilities including requiresPublicationSite.
 */
export type PublicationMode = (
  | NoPublication
  | SimpleCreateFolderInRootOnly
  | FullAllPublicationCapabilities
  | WithPublicationSiteRequiresPublicationSite
) &
  string;
export type NoPublication = "none";
export type SimpleCreateFolderInRootOnly = "simple";
export type FullAllPublicationCapabilities = "full";
export type WithPublicationSiteRequiresPublicationSite = "withSite";

export type MockConfig = {
  url: URL;
  secretField?: SecretField;
  thumbnailUrl?: ThumbnailURL;
  delay: ResponseDelay;
  searchCapability?: SearchCapability;
  paginationCapability?: PaginationCapability;
  publicationMode?: PublicationMode;
}


export declare function validate(data: any): data is MockConfig
export declare function assertValid(data: any, options?: import('@data-fair/lib-validation').AssertValidOptions): asserts data is MockConfig
export declare function returnValid(data: any, options?: import('@data-fair/lib-validation').AssertValidOptions): MockConfig
      
export declare const schema: any
        