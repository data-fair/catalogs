/* eslint-disable */
// @ts-nocheck

"use strict";
export const validate = validate14;
export default validate14;
const schema16 = {"$id":"https://github.com/data-fair/catalog-mock/import-config","x-exports":["types","validate","schema"],"title":"ImportConfig","type":"object","additionalProperties":false,"required":["nbRows"],"properties":{"nbRows":{"title":"Number of rows to import","x-i18n-title":{"fr":"Nombre de lignes à importer"},"description":"Number of rows to import. The header is always imported and does not count towards this number.","x-i18n-description":{"fr":"Nombre de lignes à importer. Le header est toujours importé et ne compte pas dans ce nombre."},"type":"integer","default":10,"minimum":5,"maximum":50},"importAttachments":{"title":"Import attachments","x-i18n-title":{"fr":"Importer les pièces jointes"},"type":"boolean","default":true}},"layout":{"title":null}};

function validate14(data, {instancePath="", parentData, parentDataProperty, rootData=data}={}){
/*# sourceURL="https://github.com/data-fair/catalog-mock/import-config" */;
let vErrors = null;
let errors = 0;
if(data && typeof data == "object" && !Array.isArray(data)){
if(data.nbRows === undefined){
const err0 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "nbRows"},message:"must have required property '"+"nbRows"+"'"};
if(vErrors === null){
vErrors = [err0];
}
else {
vErrors.push(err0);
}
errors++;
}
for(const key0 in data){
if(!((key0 === "nbRows") || (key0 === "importAttachments"))){
const err1 = {instancePath,schemaPath:"#/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key0},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err1];
}
else {
vErrors.push(err1);
}
errors++;
}
}
if(data.nbRows !== undefined){
let data0 = data.nbRows;
if(!((typeof data0 == "number") && (!(data0 % 1) && !isNaN(data0)))){
const err2 = {instancePath:instancePath+"/nbRows",schemaPath:"#/properties/nbRows/type",keyword:"type",params:{type: "integer"},message:"must be integer"};
if(vErrors === null){
vErrors = [err2];
}
else {
vErrors.push(err2);
}
errors++;
}
if(typeof data0 == "number"){
if(data0 > 50 || isNaN(data0)){
const err3 = {instancePath:instancePath+"/nbRows",schemaPath:"#/properties/nbRows/maximum",keyword:"maximum",params:{comparison: "<=", limit: 50},message:"must be <= 50"};
if(vErrors === null){
vErrors = [err3];
}
else {
vErrors.push(err3);
}
errors++;
}
if(data0 < 5 || isNaN(data0)){
const err4 = {instancePath:instancePath+"/nbRows",schemaPath:"#/properties/nbRows/minimum",keyword:"minimum",params:{comparison: ">=", limit: 5},message:"must be >= 5"};
if(vErrors === null){
vErrors = [err4];
}
else {
vErrors.push(err4);
}
errors++;
}
}
}
if(data.importAttachments !== undefined){
if(typeof data.importAttachments !== "boolean"){
const err5 = {instancePath:instancePath+"/importAttachments",schemaPath:"#/properties/importAttachments/type",keyword:"type",params:{type: "boolean"},message:"must be boolean"};
if(vErrors === null){
vErrors = [err5];
}
else {
vErrors.push(err5);
}
errors++;
}
}
}
else {
const err6 = {instancePath,schemaPath:"#/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err6];
}
else {
vErrors.push(err6);
}
errors++;
}
validate14.errors = vErrors;
return errors === 0;
}
