
export const schemaExports: string[]

// see https://github.com/bcherny/json-schema-to-typescript/issues/439 if some types are not exported
/**
 * Number of rows to import. The header is always imported and does not count towards this number.
 */
export type NumberOfRowsToImport = number;
export type ImportAttachments = boolean;

export type ImportConfig = {
  nbRows: NumberOfRowsToImport;
  importAttachments?: ImportAttachments;
}


export declare function validate(data: any): data is ImportConfig
export declare function assertValid(data: any, options?: import('@data-fair/lib-validation').AssertValidOptions): asserts data is ImportConfig
export declare function returnValid(data: any, options?: import('@data-fair/lib-validation').AssertValidOptions): ImportConfig
      
export declare const schema: any
        